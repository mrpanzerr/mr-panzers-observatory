function printPage() {
	print();
}
